#!/usr/bin/env python3
"""
02_pca_analysis.py - Principal Component Analysis
==================================================

Performs PCA on population allele frequencies and individual loci to
identify major axes of genetic variation.

Input: CSV with allele frequencies
Output: PCA coordinates, loadings, variance explained
"""

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from pathlib import Path
import sys

def perform_population_pca(df):
    """
    PCA on population allele frequencies.
    
    Parameters:
    -----------
    df : DataFrame
        Allele frequencies with columns [Gene, Uzbek_RAF, EUR_RAF, EAS_RAF]
    
    Returns:
    --------
    tuple : (pca_coords, variance_explained, pca_model)
    """
    # Prepare data matrix (populations × loci)
    X = df[['Uzbek_RAF', 'EUR_RAF', 'EAS_RAF']].values.T
    
    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # PCA
    pca = PCA(n_components=2)
    coords = pca.fit_transform(X_scaled)
    
    variance_exp = pca.explained_variance_ratio_
    
    return coords, variance_exp, pca

def perform_loci_pca(df):
    """
    PCA on loci (loci × populations).
    
    Returns loadings showing which loci contribute most to differentiation.
    """
    # Transpose: loci × populations
    X = df[['Uzbek_RAF', 'EUR_RAF', 'EAS_RAF']].values
    
    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # PCA
    pca = PCA(n_components=2)
    coords = pca.fit_transform(X_scaled)
    
    # Get loadings (components)
    loadings = pca.components_.T * np.sqrt(pca.explained_variance_)
    
    variance_exp = pca.explained_variance_ratio_
    
    return coords, loadings, variance_exp, pca

def main():
    """Main PCA analysis pipeline."""
    
    print("="*80)
    print("PRINCIPAL COMPONENT ANALYSIS")
    print("="*80)
    print()
    
    # Load data
    input_file = Path("data/allele_frequencies.csv")
    if not input_file.exists():
        print(f"ERROR: Input file not found: {input_file}")
        sys.exit(1)
    
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} variants")
    print()
    
    # Population PCA
    print("[1/2] Performing PCA on populations...")
    pop_coords, pop_var, pop_pca = perform_population_pca(df)
    
    print(f"  PC1: {pop_var[0]*100:.2f}% of variance")
    print(f"  PC2: {pop_var[1]*100:.2f}% of variance")
    print(f"  Cumulative: {sum(pop_var)*100:.2f}%")
    print()
    
    print("  Population coordinates:")
    populations = ['Uzbek', 'EUR', 'EAS']
    for i, pop in enumerate(populations):
        print(f"    {pop:6s}: PC1={pop_coords[i,0]:7.4f}, PC2={pop_coords[i,1]:7.4f}")
    print()
    
    # Save population PCA
    pop_coords_df = pd.DataFrame({
        'Population': populations,
        'PC1': pop_coords[:, 0],
        'PC2': pop_coords[:, 1]
    })
    
    # Loci PCA
    print("[2/2] Performing PCA on loci...")
    loci_coords, loadings, loci_var, loci_pca = perform_loci_pca(df)
    
    print(f"  PC1: {loci_var[0]*100:.2f}% of variance")
    print(f"  PC2: {loci_var[1]*100:.2f}% of variance")
    print(f"  Cumulative: {sum(loci_var)*100:.2f}%")
    print()
    
    # Top contributing loci
    print("  Top 10 loci contributing to PC1:")
    pc1_contrib = np.abs(loadings[:, 0])
    top_idx = np.argsort(pc1_contrib)[-10:][::-1]
    
    for rank, idx in enumerate(top_idx, 1):
        gene = df.iloc[idx]['Gene']
        loading = loadings[idx, 0]
        print(f"    {rank:2d}. {gene:15s}  loading={loading:7.4f}")
    print()
    
    # Save loci PCA
    loci_coords_df = pd.DataFrame({
        'Gene': df['Gene'],
        'PC1': loci_coords[:, 0],
        'PC2': loci_coords[:, 1]
    })
    
    loadings_df = pd.DataFrame({
        'Gene': df['Gene'],
        'PC1_loading': loadings[:, 0],
        'PC2_loading': loadings[:, 1],
        'PC1_contribution': np.abs(loadings[:, 0])
    })
    
    # Sort by contribution
    loadings_df = loadings_df.sort_values('PC1_contribution', ascending=False)
    
    # Save results
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    
    pop_coords_df.to_csv(output_dir / "pca_coordinates.csv", index=False)
    loci_coords_df.to_csv(output_dir / "loci_pca_coordinates.csv", index=False)
    loadings_df.to_csv(output_dir / "pca_gene_loadings.csv", index=False)
    
    # Save variance explained
    variance_df = pd.DataFrame({
        'Component': ['PC1', 'PC2'],
        'Variance_Explained_Population': pop_var,
        'Variance_Explained_Loci': loci_var
    })
    variance_df.to_csv(output_dir / "pca_variance_explained.csv", index=False)
    
    print("Results saved:")
    print(f"  {output_dir}/pca_coordinates.csv")
    print(f"  {output_dir}/loci_pca_coordinates.csv")
    print(f"  {output_dir}/pca_gene_loadings.csv")
    print(f"  {output_dir}/pca_variance_explained.csv")
    print()
    print("="*80)
    print("PCA ANALYSIS COMPLETE")
    print("="*80)

if __name__ == "__main__":
    main()
