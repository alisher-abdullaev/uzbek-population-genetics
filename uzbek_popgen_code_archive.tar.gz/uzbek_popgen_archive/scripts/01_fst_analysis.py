#!/usr/bin/env python3
"""
01_fst_analysis.py - FST Calculation and Bootstrap Confidence Intervals
========================================================================

Implements Weir & Cockerham (1984) FST estimator with bootstrap resampling
for confidence interval estimation.

Reference:
Weir BS, Cockerham CC. Estimating F-statistics for the analysis of 
population structure. Evolution. 1984;38(6):1358-1370.

Input: CSV with columns [Gene, Uzbek_RAF, EUR_RAF, EAS_RAF]
Output: FST matrices, bootstrap CIs, Nei's genetic distances
"""

import numpy as np
import pandas as pd
from scipy import stats
from pathlib import Path
import sys

# Configuration
N_UZBEK = 230
N_EUR = 1000
N_EAS = 1000
N_BOOTSTRAP = 10000
ALPHA = 0.05
RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)

def calculate_fst_weir_cockerham(p1, p2, n1, n2):
    """
    Calculate FST using Weir & Cockerham (1984) method.
    
    Parameters:
    -----------
    p1, p2 : float
        Allele frequencies in populations 1 and 2
    n1, n2 : int
        Sample sizes
    
    Returns:
    --------
    float : FST estimate
    """
    # Number of populations
    r = 2
    
    # Mean sample size (harmonic mean)
    n_bar = r / (1/n1 + 1/n2)
    
    # Sample size variance
    n_c = (r*n_bar - sum([n1**2, n2**2])/(r*n_bar)) / (r - 1)
    
    # Mean allele frequency
    p_bar = (n1*p1 + n2*p2) / (n1 + n2)
    
    # Sample variance in allele frequency
    s_squared = ((n1*(p1 - p_bar)**2 + n2*(p2 - p_bar)**2) / 
                 ((r - 1) * n_bar))
    
    # Expected heterozygosity
    h_bar = (n1*2*p1*(1-p1) + n2*2*p2*(1-p2)) / (n1 + n2)
    
    # Variance components
    a = (n_bar / n_c) * (s_squared - (1/(n_bar - 1)) * 
                         (p_bar*(1 - p_bar) - (r - 1)*s_squared/r - h_bar/4))
    
    b = (n_bar / (n_bar - 1)) * (p_bar*(1 - p_bar) - 
                                  (r - 1)*s_squared/r - 
                                  ((2*n_bar - 1)/(4*n_bar))*h_bar)
    
    c = h_bar / 2
    
    # FST estimate
    if (a + b + c) == 0:
        return 0.0
    
    fst = a / (a + b + c)
    return max(0.0, fst)  # FST cannot be negative

def bootstrap_fst_ci(p1, p2, n1, n2, n_bootstrap=10000, alpha=0.05):
    """
    Bootstrap confidence intervals for FST.
    
    Parameters:
    -----------
    p1, p2 : float
        Allele frequencies
    n1, n2 : int
        Sample sizes
    n_bootstrap : int
        Number of bootstrap iterations
    alpha : float
        Significance level (e.g., 0.05 for 95% CI)
    
    Returns:
    --------
    tuple : (point_estimate, lower_ci, upper_ci)
    """
    # Point estimate
    fst_obs = calculate_fst_weir_cockerham(p1, p2, n1, n2)
    
    # Bootstrap resampling
    fst_boot = []
    for _ in range(n_bootstrap):
        # Resample allele counts with replacement
        count1 = np.random.binomial(2*n1, p1)
        count2 = np.random.binomial(2*n2, p2)
        
        # Recalculate frequencies
        p1_boot = count1 / (2*n1)
        p2_boot = count2 / (2*n2)
        
        # Calculate FST for bootstrap sample
        fst_b = calculate_fst_weir_cockerham(p1_boot, p2_boot, n1, n2)
        fst_boot.append(fst_b)
    
    # Calculate percentile CIs
    lower = np.percentile(fst_boot, 100 * alpha/2)
    upper = np.percentile(fst_boot, 100 * (1 - alpha/2))
    
    return fst_obs, lower, upper

def calculate_nei_distance(p1, p2):
    """
    Calculate Nei's genetic distance (1972).
    
    D = -ln(I) where I is genetic identity
    
    Parameters:
    -----------
    p1, p2 : array-like
        Allele frequencies for all loci
    
    Returns:
    --------
    float : Nei's D
    """
    # Genetic identity
    I = np.sum(p1 * p2) / np.sqrt(np.sum(p1**2) * np.sum(p2**2))
    
    # Genetic distance
    D = -np.log(I) if I > 0 else 0
    
    return D

def main():
    """Main analysis pipeline."""
    
    print("="*80)
    print("FST ANALYSIS - Weir & Cockerham (1984) Method")
    print("="*80)
    print()
    
    # Load data
    input_file = Path("data/allele_frequencies.csv")
    if not input_file.exists():
        print(f"ERROR: Input file not found: {input_file}")
        print("Expected columns: Gene, Uzbek_RAF, EUR_RAF, EAS_RAF")
        sys.exit(1)
    
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} variants from {input_file}")
    print()
    
    # Validate columns
    required_cols = ['Gene', 'Uzbek_RAF', 'EUR_RAF', 'EAS_RAF']
    if not all(col in df.columns for col in required_cols):
        print(f"ERROR: Missing required columns. Found: {list(df.columns)}")
        sys.exit(1)
    
    # Calculate pairwise FST with bootstrap CIs
    print("Calculating pairwise FST values with bootstrap CIs...")
    print(f"Bootstrap iterations: {N_BOOTSTRAP}")
    print()
    
    results = []
    
    for idx, row in df.iterrows():
        gene = row['Gene']
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Uzbek vs EUR
        fst_ue, ci_ue_low, ci_ue_up = bootstrap_fst_ci(
            p_uzb, p_eur, N_UZBEK, N_EUR, N_BOOTSTRAP, ALPHA
        )
        
        # Uzbek vs EAS
        fst_ua, ci_ua_low, ci_ua_up = bootstrap_fst_ci(
            p_uzb, p_eas, N_UZBEK, N_EAS, N_BOOTSTRAP, ALPHA
        )
        
        # EUR vs EAS
        fst_ea, ci_ea_low, ci_ea_up = bootstrap_fst_ci(
            p_eur, p_eas, N_EUR, N_EAS, N_BOOTSTRAP, ALPHA
        )
        
        results.append({
            'Gene': gene,
            'Uzbek_RAF': p_uzb,
            'EUR_RAF': p_eur,
            'EAS_RAF': p_eas,
            'FST_Uzbek_EUR': fst_ue,
            'FST_Uzbek_EUR_CI_lower': ci_ue_low,
            'FST_Uzbek_EUR_CI_upper': ci_ue_up,
            'FST_Uzbek_EAS': fst_ua,
            'FST_Uzbek_EAS_CI_lower': ci_ua_low,
            'FST_Uzbek_EAS_CI_upper': ci_ua_up,
            'FST_EUR_EAS': fst_ea,
            'FST_EUR_EAS_CI_lower': ci_ea_low,
            'FST_EUR_EAS_CI_upper': ci_ea_up
        })
        
        if (idx + 1) % 10 == 0:
            print(f"  Processed {idx + 1}/{len(df)} loci...")
    
    results_df = pd.DataFrame(results)
    
    # Calculate overall FST (weighted by locus)
    print("\nOverall FST estimates (mean across loci):")
    print(f"  Uzbek vs EUR: {results_df['FST_Uzbek_EUR'].mean():.4f}")
    print(f"  Uzbek vs EAS: {results_df['FST_Uzbek_EAS'].mean():.4f}")
    print(f"  EUR vs EAS:   {results_df['FST_EUR_EAS'].mean():.4f}")
    print()
    
    # Calculate Nei's genetic distances
    print("Calculating Nei's genetic distances...")
    
    nei_uzb_eur = calculate_nei_distance(
        df['Uzbek_RAF'].values, df['EUR_RAF'].values
    )
    nei_uzb_eas = calculate_nei_distance(
        df['Uzbek_RAF'].values, df['EAS_RAF'].values
    )
    nei_eur_eas = calculate_nei_distance(
        df['EUR_RAF'].values, df['EAS_RAF'].values
    )
    
    print(f"  Uzbek vs EUR: {nei_uzb_eur:.4f}")
    print(f"  Uzbek vs EAS: {nei_uzb_eas:.4f}")
    print(f"  EUR vs EAS:   {nei_eur_eas:.4f}")
    print()
    
    # Create FST matrix
    fst_matrix = pd.DataFrame({
        'Population': ['Uzbek', 'EUR', 'EAS'],
        'Uzbek': [0, results_df['FST_Uzbek_EUR'].mean(), 
                  results_df['FST_Uzbek_EAS'].mean()],
        'EUR': [results_df['FST_Uzbek_EUR'].mean(), 0, 
                results_df['FST_EUR_EAS'].mean()],
        'EAS': [results_df['FST_Uzbek_EAS'].mean(), 
                results_df['FST_EUR_EAS'].mean(), 0]
    })
    
    # Create Nei's D matrix
    nei_matrix = pd.DataFrame({
        'Population': ['Uzbek', 'EUR', 'EAS'],
        'Uzbek': [0, nei_uzb_eur, nei_uzb_eas],
        'EUR': [nei_uzb_eur, 0, nei_eur_eas],
        'EAS': [nei_uzb_eas, nei_eur_eas, 0]
    })
    
    # Save results
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    
    results_df.to_csv(output_dir / "fst_results.csv", index=False)
    fst_matrix.to_csv(output_dir / "fst_matrix.csv", index=False)
    nei_matrix.to_csv(output_dir / "nei_matrix.csv", index=False)
    
    print("Results saved:")
    print(f"  {output_dir}/fst_results.csv")
    print(f"  {output_dir}/fst_matrix.csv")
    print(f"  {output_dir}/nei_matrix.csv")
    print()
    print("="*80)
    print("FST ANALYSIS COMPLETE")
    print("="*80)

if __name__ == "__main__":
    main()
