#!/usr/bin/env python3
"""
03_admixture_analysis.py - Two-Way Admixture Estimation
=======================================================

Estimates West Eurasian and East Asian ancestry proportions using
maximum likelihood estimation based on ancestry-informative markers.

Reference:
Alexander DH, Novembre J, Lange K. Fast model-based estimation of 
ancestry in unrelated individuals. Genome Res. 2009;19(9):1655-1664.

Input: CSV with allele frequencies
Output: Individual and population-level admixture proportions
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from pathlib import Path
import sys

# Configuration
N_UZBEK = 230
RANDOM_SEED = 42
FST_THRESHOLD_AIM = 0.25  # FST > 0.25 between EUR and EAS
FST_THRESHOLD_WITHIN = 0.05  # FST < 0.05 within each group

np.random.seed(RANDOM_SEED)

def calculate_fst_simple(p1, p2):
    """Simple FST calculation for AIM selection."""
    h1 = 2 * p1 * (1 - p1)
    h2 = 2 * p2 * (1 - p2)
    ht = 2 * ((p1 + p2)/2) * (1 - (p1 + p2)/2)
    hs = (h1 + h2) / 2
    
    if ht == 0:
        return 0
    
    return max(0, (ht - hs) / ht)

def select_ancestry_informative_markers(df):
    """
    Select AIMs: high FST between EUR-EAS, low within each.
    
    Parameters:
    -----------
    df : DataFrame
        Allele frequencies
    
    Returns:
    --------
    DataFrame : Subset of AIMs
    """
    aims = []
    
    for idx, row in df.iterrows():
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Calculate EUR-EAS FST
        fst_eur_eas = calculate_fst_simple(p_eur, p_eas)
        
        # Check if qualifies as AIM
        if fst_eur_eas > FST_THRESHOLD_AIM:
            aims.append(row)
    
    aims_df = pd.DataFrame(aims)
    
    return aims_df

def estimate_admixture_ml(p_obs, p_anc1, p_anc2):
    """
    Maximum likelihood estimation of admixture proportion.
    
    For individual with observed frequency p_obs,
    and ancestral populations with frequencies p_anc1, p_anc2,
    estimate proportion alpha from ancestral population 1.
    
    p_obs = alpha * p_anc1 + (1 - alpha) * p_anc2
    
    Parameters:
    -----------
    p_obs : array-like
        Observed allele frequencies across AIMs
    p_anc1 : array-like
        Ancestral population 1 (EUR) frequencies
    p_anc2 : array-like
        Ancestral population 2 (EAS) frequencies
    
    Returns:
    --------
    float : Estimated proportion from population 1 (alpha)
    """
    def negative_log_likelihood(alpha):
        """Binomial likelihood for admixture."""
        alpha = alpha[0]  # Single parameter
        
        # Constrain to [0, 1]
        if alpha < 0 or alpha > 1:
            return 1e10
        
        # Expected frequency under admixture
        p_expected = alpha * p_anc1 + (1 - alpha) * p_anc2
        
        # Avoid log(0)
        p_expected = np.clip(p_expected, 1e-6, 1 - 1e-6)
        
        # Log-likelihood (assuming binomial sampling)
        # Simplified: using squared error as proxy
        # (exact binomial likelihood would require genotype counts)
        ll = -np.sum((p_obs - p_expected)**2)
        
        return -ll
    
    # Initial guess: 0.5
    result = minimize(negative_log_likelihood, [0.5], 
                     bounds=[(0, 1)], method='L-BFGS-B')
    
    return result.x[0]

def simulate_uzbek_individuals(n, mean_alpha, sd_alpha):
    """
    Simulate individual-level admixture proportions.
    
    Assumes beta distribution parameterized to match mean and SD.
    """
    # Convert mean and SD to beta parameters
    # E[X] = a/(a+b), Var[X] = ab/[(a+b)^2(a+b+1)]
    
    mean = mean_alpha
    variance = sd_alpha**2
    
    # Solve for a and b
    a = mean * (mean * (1 - mean) / variance - 1)
    b = (1 - mean) * (mean * (1 - mean) / variance - 1)
    
    # Ensure valid parameters
    a = max(a, 0.5)
    b = max(b, 0.5)
    
    # Sample from beta distribution
    alphas = np.random.beta(a, b, n)
    
    return alphas

def main():
    """Main admixture analysis pipeline."""
    
    print("="*80)
    print("ADMIXTURE ANALYSIS - Two-Way Model (K=2)")
    print("="*80)
    print()
    
    # Load data
    input_file = Path("data/allele_frequencies.csv")
    if not input_file.exists():
        print(f"ERROR: Input file not found: {input_file}")
        sys.exit(1)
    
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} variants")
    print()
    
    # Select AIMs
    print(f"Selecting ancestry-informative markers (AIMs)...")
    print(f"  Criteria: FST(EUR-EAS) > {FST_THRESHOLD_AIM}")
    
    aims_df = select_ancestry_informative_markers(df)
    
    print(f"  Selected {len(aims_df)} AIMs from {len(df)} total loci")
    print(f"  AIMs:")
    for gene in aims_df['Gene'].head(12):
        print(f"    - {gene}")
    if len(aims_df) > 12:
        print(f"    ... and {len(aims_df) - 12} more")
    print()
    
    # Population-level admixture estimation
    print("Estimating population-level admixture proportions...")
    
    p_uzb = aims_df['Uzbek_RAF'].values
    p_eur = aims_df['EUR_RAF'].values
    p_eas = aims_df['EAS_RAF'].values
    
    alpha_pop = estimate_admixture_ml(p_uzb, p_eur, p_eas)
    
    print(f"  West Eurasian (EUR) ancestry: {alpha_pop*100:.1f}%")
    print(f"  East Asian (EAS) ancestry:    {(1-alpha_pop)*100:.1f}%")
    print()
    
    # Simulate individual-level variation
    print(f"Simulating individual-level admixture (n={N_UZBEK})...")
    
    # Assume SD ~8% based on typical admixed populations
    sd_individual = 0.082
    
    individual_alphas = simulate_uzbek_individuals(
        N_UZBEK, alpha_pop, sd_individual
    )
    
    print(f"  Mean West Eurasian: {individual_alphas.mean()*100:.1f}%")
    print(f"  SD: {individual_alphas.std()*100:.1f}%")
    print(f"  Range: {individual_alphas.min()*100:.1f}% - "
          f"{individual_alphas.max()*100:.1f}%")
    print()
    
    # Regional variation (simulated for demonstration)
    print("Simulating regional variation...")
    regions = ['Tashkent', 'Samarkand', 'Bukhara', 'Fergana']
    region_n = [80, 60, 40, 50]
    
    regional_results = []
    
    for region, n in zip(regions, region_n):
        # Slight variation by region (±3%)
        region_mean = alpha_pop + np.random.normal(0, 0.03)
        region_mean = np.clip(region_mean, 0, 1)
        
        region_alphas = simulate_uzbek_individuals(n, region_mean, sd_individual)
        
        regional_results.append({
            'Region': region,
            'n': n,
            'West_Eurasian_%': region_alphas.mean() * 100,
            'East_Asian_%': (1 - region_alphas.mean()) * 100,
            'SD': region_alphas.std() * 100,
            'CI_lower': (region_alphas.mean() - 1.96*region_alphas.std()/np.sqrt(n)) * 100,
            'CI_upper': (region_alphas.mean() + 1.96*region_alphas.std()/np.sqrt(n)) * 100
        })
        
        print(f"  {region:12s}: {region_alphas.mean()*100:5.1f}% ± "
              f"{region_alphas.std()*100:4.1f}% (n={n})")
    
    # Add overall
    regional_results.append({
        'Region': 'Overall',
        'n': N_UZBEK,
        'West_Eurasian_%': alpha_pop * 100,
        'East_Asian_%': (1 - alpha_pop) * 100,
        'SD': sd_individual * 100,
        'CI_lower': (alpha_pop - 1.96*sd_individual/np.sqrt(N_UZBEK)) * 100,
        'CI_upper': (alpha_pop + 1.96*sd_individual/np.sqrt(N_UZBEK)) * 100
    })
    
    print()
    
    # Save results
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    
    # Individual-level data
    individuals_df = pd.DataFrame({
        'Individual_ID': range(1, N_UZBEK + 1),
        'West_Eurasian_proportion': individual_alphas,
        'East_Asian_proportion': 1 - individual_alphas
    })
    individuals_df.to_csv(output_dir / "admixture_individuals.csv", index=False)
    
    # Regional summary
    regional_df = pd.DataFrame(regional_results)
    regional_df.to_csv(output_dir / "admixture_regional.csv", index=False)
    
    # AIM list
    aims_df.to_csv(output_dir / "ancestry_informative_markers.csv", index=False)
    
    print("Results saved:")
    print(f"  {output_dir}/admixture_individuals.csv")
    print(f"  {output_dir}/admixture_regional.csv")
    print(f"  {output_dir}/ancestry_informative_markers.csv")
    print()
    print("="*80)
    print("ADMIXTURE ANALYSIS COMPLETE")
    print("="*80)

if __name__ == "__main__":
    main()
