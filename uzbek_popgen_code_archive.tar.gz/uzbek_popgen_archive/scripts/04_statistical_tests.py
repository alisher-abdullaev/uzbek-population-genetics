#!/usr/bin/env python3
"""
04_statistical_tests.py - Comprehensive Population Differentiation Tests
========================================================================

Implements:
1. Chi-square test with Bonferroni correction
2. Fisher's Exact test
3. G-test (likelihood ratio test)
4. Cochran-Armitage trend test
5. Mantel test for isolation by distance

Input: CSV with allele frequencies
Output: Test statistics, p-values, significance flags
"""

import numpy as np
import pandas as pd
from scipy import stats
from scipy.spatial.distance import pdist, squareform
from pathlib import Path
import sys

# Configuration
N_UZBEK = 230
N_EUR = 1000
N_EAS = 1000
ALPHA = 0.05
RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)

def chi_square_test_bonferroni(df, alpha=0.05):
    """
    Chi-square test for 3-population allele frequency differences.
    Applies Bonferroni correction for multiple testing.
    
    Returns:
    --------
    DataFrame : Chi-square statistics, p-values, significance
    """
    n_tests = len(df)
    bonferroni_alpha = alpha / n_tests
    
    results = []
    
    for idx, row in df.iterrows():
        gene = row['Gene']
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Observed counts (alleles)
        obs_ref = [int(p_uzb * 2 * N_UZBEK), 
                   int(p_eur * 2 * N_EUR),
                   int(p_eas * 2 * N_EAS)]
        
        obs_alt = [2*N_UZBEK - obs_ref[0],
                   2*N_EUR - obs_ref[1],
                   2*N_EAS - obs_ref[2]]
        
        # Create contingency table
        observed = np.array([obs_ref, obs_alt])
        
        # Chi-square test
        chi2, pval, dof, expected = stats.chi2_contingency(observed)
        
        results.append({
            'Gene': gene,
            'Chi2': chi2,
            'df': dof,
            'p-value': pval,
            'Bonferroni_threshold': bonferroni_alpha,
            'Bonferroni_Significant': pval < bonferroni_alpha,
            'Nominal_Significant': pval < alpha
        })
    
    return pd.DataFrame(results)

def fishers_exact_pairwise(df):
    """
    Fisher's Exact test for pairwise comparisons.
    
    Returns:
    --------
    DataFrame : Odds ratios, p-values for each pair
    """
    results = []
    
    for idx, row in df.iterrows():
        gene = row['Gene']
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Create 2x2 tables for each pair
        
        # Uzbek vs EUR
        table_ue = [
            [int(p_uzb * 2 * N_UZBEK), 2*N_UZBEK - int(p_uzb * 2 * N_UZBEK)],
            [int(p_eur * 2 * N_EUR), 2*N_EUR - int(p_eur * 2 * N_EUR)]
        ]
        or_ue, pval_ue = stats.fisher_exact(table_ue)
        
        # Uzbek vs EAS
        table_ua = [
            [int(p_uzb * 2 * N_UZBEK), 2*N_UZBEK - int(p_uzb * 2 * N_UZBEK)],
            [int(p_eas * 2 * N_EAS), 2*N_EAS - int(p_eas * 2 * N_EAS)]
        ]
        or_ua, pval_ua = stats.fisher_exact(table_ua)
        
        # EUR vs EAS
        table_ea = [
            [int(p_eur * 2 * N_EUR), 2*N_EUR - int(p_eur * 2 * N_EUR)],
            [int(p_eas * 2 * N_EAS), 2*N_EAS - int(p_eas * 2 * N_EAS)]
        ]
        or_ea, pval_ea = stats.fisher_exact(table_ea)
        
        # Bonferroni correction
        bonf_alpha = ALPHA / len(df)
        
        results.append({
            'Gene': gene,
            'OR_Uzbek_EUR': or_ue,
            'p_Uzbek_EUR': pval_ue,
            'Significant_Uzbek_EUR': pval_ue < bonf_alpha,
            'OR_Uzbek_EAS': or_ua,
            'p_Uzbek_EAS': pval_ua,
            'Significant_Uzbek_EAS': pval_ua < bonf_alpha,
            'OR_EUR_EAS': or_ea,
            'p_EUR_EAS': pval_ea,
            'Significant_EUR_EAS': pval_ea < bonf_alpha
        })
    
    return pd.DataFrame(results)

def g_test(df):
    """
    G-test (likelihood ratio test) as alternative to chi-square.
    
    G = 2 * sum(observed * ln(observed/expected))
    """
    results = []
    
    for idx, row in df.iterrows():
        gene = row['Gene']
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Observed counts
        obs_ref = np.array([int(p_uzb * 2 * N_UZBEK), 
                            int(p_eur * 2 * N_EUR),
                            int(p_eas * 2 * N_EAS)])
        
        obs_alt = np.array([2*N_UZBEK - obs_ref[0],
                            2*N_EUR - obs_ref[1],
                            2*N_EAS - obs_ref[2]])
        
        observed = np.array([obs_ref, obs_alt])
        
        # Expected counts (chi-square)
        chi2, pval_chi, dof, expected = stats.chi2_contingency(observed)
        
        # G-statistic
        # Avoid log(0)
        observed_safe = observed + 0.5
        expected_safe = expected + 0.5
        
        G = 2 * np.sum(observed_safe * np.log(observed_safe / expected_safe))
        
        # P-value from chi-square distribution
        pval_g = 1 - stats.chi2.cdf(G, dof)
        
        # Bonferroni
        bonf_alpha = ALPHA / len(df)
        
        results.append({
            'Gene': gene,
            'G_statistic': G,
            'df': dof,
            'p_value': pval_g,
            'Chi2_statistic': chi2,
            'p_value_chi2': pval_chi,
            'Bonferroni_Significant': pval_g < bonf_alpha
        })
    
    return pd.DataFrame(results)

def cochran_armitage_trend_test(df):
    """
    Cochran-Armitage trend test for ordered populations.
    
    Tests for linear trend in proportions across
    Uzbek → EUR → EAS geographic axis.
    """
    results = []
    
    for idx, row in df.iterrows():
        gene = row['Gene']
        p_uzb = row['Uzbek_RAF']
        p_eur = row['EUR_RAF']
        p_eas = row['EAS_RAF']
        
        # Assign scores (geographic ordering)
        # Uzbek=0, EUR=1, EAS=2
        scores = np.array([0, 1, 2])
        
        # Counts
        successes = np.array([int(p_uzb * 2 * N_UZBEK),
                             int(p_eur * 2 * N_EUR),
                             int(p_eas * 2 * N_EAS)])
        
        totals = np.array([2*N_UZBEK, 2*N_EUR, 2*N_EAS])
        
        # Calculate test statistic
        n_total = totals.sum()
        p_total = successes.sum() / n_total
        
        # Weighted mean score
        mean_score = (scores * totals).sum() / n_total
        
        # Numerator
        numerator = ((scores - mean_score) * successes).sum()
        
        # Denominator
        variance = p_total * (1 - p_total) * ((scores - mean_score)**2 * totals).sum()
        
        if variance > 0:
            z_stat = numerator / np.sqrt(variance)
            p_value = 2 * (1 - stats.norm.cdf(abs(z_stat)))
        else:
            z_stat = 0
            p_value = 1.0
        
        # Determine trend direction
        if p_uzb < p_eur < p_eas:
            trend = 'Increasing'
        elif p_uzb > p_eur > p_eas:
            trend = 'Decreasing'
        else:
            trend = 'Non-monotonic'
        
        # Bonferroni
        bonf_alpha = ALPHA / len(df)
        
        results.append({
            'Gene': gene,
            'Z_statistic': z_stat,
            'p_value': p_value,
            'Trend': trend,
            'Bonferroni_Significant': p_value < bonf_alpha
        })
    
    return pd.DataFrame(results)

def mantel_test(fst_matrix, geo_distances, n_permutations=9999):
    """
    Mantel test for correlation between genetic and geographic distances.
    
    Tests isolation by distance hypothesis.
    
    Parameters:
    -----------
    fst_matrix : array-like (3x3)
        Pairwise FST matrix
    geo_distances : array-like (3x3)
        Geographic distances in km
    n_permutations : int
        Number of permutations for significance test
    
    Returns:
    --------
    dict : Correlation, p-value
    """
    # Extract upper triangle (pairwise distances)
    fst_vec = squareform(fst_matrix, checks=False)
    geo_vec = squareform(geo_distances, checks=False)
    
    # Linearized FST for better normality
    fst_linear = fst_vec / (1 - fst_vec + 1e-10)
    
    # Observed correlation
    r_obs = np.corrcoef(fst_linear, geo_vec)[0, 1]
    
    # Permutation test
    n_greater = 0
    
    for _ in range(n_permutations):
        # Permute one of the distance matrices
        perm_idx = np.random.permutation(3)
        
        # Create permuted matrix
        geo_perm = geo_distances[perm_idx, :][:, perm_idx]
        geo_vec_perm = squareform(geo_perm, checks=False)
        
        # Calculate correlation for permutation
        r_perm = np.corrcoef(fst_linear, geo_vec_perm)[0, 1]
        
        if abs(r_perm) >= abs(r_obs):
            n_greater += 1
    
    # P-value (two-tailed)
    p_value = (n_greater + 1) / (n_permutations + 1)
    
    return {
        'r_raw_FST': np.corrcoef(fst_vec, geo_vec)[0, 1],
        'r_linearized_FST': r_obs,
        'p_value': p_value,
        'n_permutations': n_permutations
    }

def main():
    """Main statistical testing pipeline."""
    
    print("="*80)
    print("COMPREHENSIVE STATISTICAL TESTS")
    print("="*80)
    print()
    
    # Load data
    input_file = Path("data/allele_frequencies.csv")
    if not input_file.exists():
        print(f"ERROR: Input file not found: {input_file}")
        sys.exit(1)
    
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} variants")
    print()
    
    # Test 1: Chi-square
    print("[1/5] Chi-square test with Bonferroni correction...")
    chi2_results = chi_square_test_bonferroni(df, ALPHA)
    n_sig_bonf = chi2_results['Bonferroni_Significant'].sum()
    print(f"  {n_sig_bonf}/{len(df)} loci significant after Bonferroni")
    print()
    
    # Test 2: Fisher's Exact
    print("[2/5] Fisher's Exact test (pairwise)...")
    fisher_results = fishers_exact_pairwise(df)
    print(f"  Uzbek-EUR: {fisher_results['Significant_Uzbek_EUR'].sum()}/{len(df)} significant")
    print(f"  Uzbek-EAS: {fisher_results['Significant_Uzbek_EAS'].sum()}/{len(df)} significant")
    print(f"  EUR-EAS:   {fisher_results['Significant_EUR_EAS'].sum()}/{len(df)} significant")
    print()
    
    # Test 3: G-test
    print("[3/5] G-test (likelihood ratio)...")
    g_results = g_test(df)
    n_sig_g = g_results['Bonferroni_Significant'].sum()
    print(f"  {n_sig_g}/{len(df)} loci significant after Bonferroni")
    print()
    
    # Test 4: Cochran-Armitage
    print("[4/5] Cochran-Armitage trend test...")
    ca_results = cochran_armitage_trend_test(df)
    n_sig_ca = ca_results['Bonferroni_Significant'].sum()
    
    trend_counts = ca_results['Trend'].value_counts()
    print(f"  {n_sig_ca}/{len(df)} loci show significant trend")
    print(f"  Trend patterns:")
    for trend, count in trend_counts.items():
        print(f"    {trend}: {count} loci")
    print()
    
    # Test 5: Mantel test
    print("[5/5] Mantel test (isolation by distance)...")
    
    # Load FST matrix
    fst_file = Path("outputs/fst_matrix.csv")
    if fst_file.exists():
        fst_df = pd.read_csv(fst_file)
        fst_matrix = fst_df[['Uzbek', 'EUR', 'EAS']].values
        
        # Geographic distances (km, approximate)
        # Tashkent - Paris: ~4,232 km
        # Tashkent - Beijing: ~4,010 km
        # Paris - Beijing: ~7,743 km
        geo_distances = np.array([
            [0, 4232, 4010],
            [4232, 0, 7743],
            [4010, 7743, 0]
        ])
        
        mantel_result = mantel_test(fst_matrix, geo_distances, 9999)
        
        print(f"  Correlation (raw FST vs distance): r = {mantel_result['r_raw_FST']:.3f}")
        print(f"  Correlation (linearized FST vs distance): r = {mantel_result['r_linearized_FST']:.3f}")
        print(f"  P-value: {mantel_result['p_value']:.3f}")
        print(f"  Permutations: {mantel_result['n_permutations']}")
    else:
        print("  FST matrix not found. Run 01_fst_analysis.py first.")
        mantel_result = None
    
    print()
    
    # Save results
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    
    chi2_results.to_csv(output_dir / "chi_square_results.csv", index=False)
    fisher_results.to_csv(output_dir / "fisher_exact_results.csv", index=False)
    g_results.to_csv(output_dir / "gtest_results.csv", index=False)
    ca_results.to_csv(output_dir / "cochran_armitage_results.csv", index=False)
    
    if mantel_result:
        mantel_df = pd.DataFrame([mantel_result])
        mantel_df.to_csv(output_dir / "mantel_results.csv", index=False)
    
    print("Results saved:")
    print(f"  {output_dir}/chi_square_results.csv")
    print(f"  {output_dir}/fisher_exact_results.csv")
    print(f"  {output_dir}/gtest_results.csv")
    print(f"  {output_dir}/cochran_armitage_results.csv")
    if mantel_result:
        print(f"  {output_dir}/mantel_results.csv")
    print()
    print("="*80)
    print("STATISTICAL TESTS COMPLETE")
    print("="*80)

if __name__ == "__main__":
    main()
