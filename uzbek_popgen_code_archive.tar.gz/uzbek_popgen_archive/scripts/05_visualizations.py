#!/usr/bin/env python3
"""
05_visualizations.py - Publication-Quality Figures
==================================================

Generates all figures reported in the manuscript at 300 dpi.

Requires outputs from scripts 01-04.

Output: PNG figures at 300 dpi, publication-ready
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
import sys

# Configuration
DPI = 300
FIGSIZE_SINGLE = (8, 6)
FIGSIZE_MULTI = (16, 12)

# Set publication-quality style
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.linewidth'] = 1.2
plt.rcParams['xtick.major.width'] = 1.2
plt.rcParams['ytick.major.width'] = 1.2

def check_inputs():
    """Verify all required input files exist."""
    required_files = [
        "outputs/fst_results.csv",
        "outputs/pca_coordinates.csv",
        "outputs/admixture_individuals.csv",
        "outputs/chi_square_results.csv"
    ]
    
    missing = []
    for f in required_files:
        if not Path(f).exists():
            missing.append(f)
    
    if missing:
        print("ERROR: Missing required input files:")
        for f in missing:
            print(f"  - {f}")
        print("\nRun scripts 01-04 first.")
        sys.exit(1)

def plot_fst_manhattan():
    """
    Figure 4: FST Manhattan plot showing locus-specific differentiation.
    """
    print("[1/5] Creating FST Manhattan plot...")
    
    df = pd.read_csv("outputs/fst_results.csv")
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 10), sharex=True)
    
    x = np.arange(len(df))
    
    # Panel A: Uzbek-EUR
    colors_a = ['#E74C3C' if f > 0.10 else '#3498DB' if f > 0.05 else '#95A5A6' 
                for f in df['FST_Uzbek_EUR']]
    
    ax1.bar(x, df['FST_Uzbek_EUR'], color=colors_a, width=0.8, edgecolor='none', alpha=0.8)
    ax1.axhline(0.05, color='orange', ls='--', lw=1.5, label='Moderate (0.05)')
    ax1.axhline(0.10, color='red', ls='--', lw=1.5, label='High (0.10)')
    ax1.set_ylabel('F$_{ST}$ (Uzbek vs EUR)', fontsize=13, fontweight='bold')
    ax1.set_title('A   Locus-specific Population Differentiation', 
                  fontsize=14, fontweight='bold', loc='left')
    ax1.legend(fontsize=10, loc='upper right', frameon=True, fancybox=True)
    ax1.grid(alpha=0.3, axis='y', linestyle=':')
    ax1.set_ylim(0, df['FST_Uzbek_EUR'].max()*1.15)
    
    # Annotate top 5
    top5 = df.nlargest(5, 'FST_Uzbek_EUR')
    for _, row in top5.iterrows():
        idx = np.where(df['Gene'] == row['Gene'])[0][0]
        ax1.text(idx, row['FST_Uzbek_EUR']+0.01, row['Gene'].split('_')[0], 
                rotation=90, fontsize=8, va='bottom', ha='center', style='italic')
    
    # Panel B: Uzbek-EAS
    colors_b = ['#E74C3C' if f > 0.15 else '#3498DB' if f > 0.08 else '#95A5A6' 
                for f in df['FST_Uzbek_EAS']]
    
    ax2.bar(x, df['FST_Uzbek_EAS'], color=colors_b, width=0.8, edgecolor='none', alpha=0.8)
    ax2.axhline(0.08, color='orange', ls='--', lw=1.5, label='Moderate (0.08)')
    ax2.axhline(0.15, color='red', ls='--', lw=1.5, label='High (0.15)')
    ax2.set_ylabel('F$_{ST}$ (Uzbek vs EAS)', fontsize=13, fontweight='bold')
    ax2.set_title('B   Uzbek-East Asian Differentiation', 
                  fontsize=14, fontweight='bold', loc='left')
    ax2.set_xlabel('Locus Index', fontsize=12, fontweight='bold')
    ax2.legend(fontsize=10, loc='upper right', frameon=True, fancybox=True)
    ax2.grid(alpha=0.3, axis='y', linestyle=':')
    ax2.set_ylim(0, df['FST_Uzbek_EAS'].max()*1.15)
    
    # Annotate top 5
    top5_eas = df.nlargest(5, 'FST_Uzbek_EAS')
    for _, row in top5_eas.iterrows():
        idx = np.where(df['Gene'] == row['Gene'])[0][0]
        ax2.text(idx, row['FST_Uzbek_EAS']+0.02, row['Gene'].split('_')[0], 
                rotation=90, fontsize=8, va='bottom', ha='center', style='italic')
    
    plt.tight_layout()
    plt.savefig('outputs/Figure4_FST_Manhattan.png', dpi=DPI, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Figure4_FST_Manhattan.png")

def plot_admixture_barplot():
    """
    Figure 6: Individual-level ancestry proportions barplot.
    """
    print("[2/5] Creating admixture barplot...")
    
    df = pd.read_csv("outputs/admixture_individuals.csv")
    
    # Sort by West Eurasian proportion
    df = df.sort_values('West_Eurasian_proportion', ascending=False)
    
    fig, ax = plt.subplots(figsize=(16, 5))
    
    x = np.arange(len(df))
    
    # Stacked bar
    ax.bar(x, df['West_Eurasian_proportion'], color='#3498DB', 
           label='West Eurasian', width=1, edgecolor='none')
    ax.bar(x, df['East_Asian_proportion'], 
           bottom=df['West_Eurasian_proportion'],
           color='#E74C3C', label='East Asian', width=1, edgecolor='none')
    
    # Mean line
    mean_west = df['West_Eurasian_proportion'].mean()
    ax.axhline(mean_west, color='black', ls='--', lw=2, 
              label=f'Mean = {mean_west*100:.1f}%')
    
    # Stats box
    stats_text = (f"n = {len(df)}\n"
                 f"Mean ± SD:\n"
                 f"  West Eur: {mean_west*100:.1f} ± {df['West_Eurasian_proportion'].std()*100:.1f}%\n"
                 f"  East Asian: {(1-mean_west)*100:.1f} ± {df['East_Asian_proportion'].std()*100:.1f}%")
    
    ax.text(0.02, 0.97, stats_text, transform=ax.transAxes, 
           fontsize=10, verticalalignment='top',
           bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
    
    ax.set_xlabel('Individual (sorted by ancestry proportion)', fontsize=13, fontweight='bold')
    ax.set_ylabel('Ancestry Proportion', fontsize=13, fontweight='bold')
    ax.set_title('Admixture Analysis: Two-Way Model (K=2)', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11, loc='upper right', frameon=True, fancybox=True)
    ax.set_ylim(0, 1)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(['0%', '25%', '50%', '75%', '100%'])
    ax.grid(alpha=0.2, axis='y', linestyle=':')
    
    plt.tight_layout()
    plt.savefig('outputs/Figure6_Admixture_Barplot.png', dpi=DPI, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Figure6_Admixture_Barplot.png")

def plot_pca_biplot():
    """
    Figure 3: PCA biplot with population clustering.
    """
    print("[3/5] Creating PCA biplot...")
    
    pop_df = pd.read_csv("outputs/pca_coordinates.csv")
    loadings_df = pd.read_csv("outputs/pca_gene_loadings.csv")
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Population points
    colors = {'Uzbek': '#9B59B6', 'EUR': '#3498DB', 'EAS': '#E74C3C'}
    markers = {'Uzbek': 'D', 'EUR': 'o', 'EAS': '^'}
    
    for pop in pop_df['Population']:
        data = pop_df[pop_df['Population'] == pop]
        ax.scatter(data['PC1'], data['PC2'], 
                  s=500, c=colors[pop], marker=markers[pop],
                  edgecolor='black', linewidth=2, 
                  label=pop, alpha=0.8, zorder=5)
        
        # Add label
        ax.text(data['PC1'].values[0], data['PC2'].values[0] + 0.3, 
               pop, fontsize=14, fontweight='bold', 
               ha='center', va='bottom')
    
    # Top 10 gene loadings as arrows
    top_genes = loadings_df.nlargest(10, 'PC1_contribution')
    
    scale = 1.4  # Arrow scaling
    
    for _, gene_data in top_genes.iterrows():
        ax.arrow(0, 0, 
                gene_data['PC1_loading'] * scale,
                gene_data['PC2_loading'] * scale,
                head_width=0.15, head_length=0.1,
                fc='gray', ec='gray', alpha=0.6, linewidth=1.5)
        
        # Gene label
        gene_name = gene_data['Gene'].split('_')[0]
        ax.text(gene_data['PC1_loading'] * scale * 1.1,
               gene_data['PC2_loading'] * scale * 1.1,
               gene_name, fontsize=9, style='italic',
               bbox=dict(boxstyle='round,pad=0.3', 
                        facecolor='white', edgecolor='red', alpha=0.7))
    
    ax.set_xlabel('PC1 (82.4% variance)', fontsize=13, fontweight='bold')
    ax.set_ylabel('PC2 (17.6% variance)', fontsize=13, fontweight='bold')
    ax.set_title('PCA Biplot: Population Clustering with Gene Loadings',
                fontsize=14, fontweight='bold')
    ax.legend(fontsize=11, loc='upper left', frameon=True, fancybox=True)
    ax.grid(alpha=0.3, linestyle=':')
    ax.axhline(0, color='k', linewidth=0.5)
    ax.axvline(0, color='k', linewidth=0.5)
    
    plt.tight_layout()
    plt.savefig('outputs/Figure3_PCA_Biplot.png', dpi=DPI, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Figure3_PCA_Biplot.png")

def plot_statistical_summary():
    """
    Supplementary Figure: Statistical test summary.
    """
    print("[4/5] Creating statistical test summary...")
    
    chi2 = pd.read_csv("outputs/chi_square_results.csv")
    fisher = pd.read_csv("outputs/fisher_exact_results.csv")
    gtest = pd.read_csv("outputs/gtest_results.csv")
    ca = pd.read_csv("outputs/cochran_armitage_results.csv")
    
    fig = plt.figure(figsize=(16, 10))
    gs = gridspec.GridSpec(2, 3, figure=fig)
    
    # Panel A: Chi-square Manhattan
    ax1 = fig.add_subplot(gs[0, :])
    x = np.arange(len(chi2))
    
    colors = ['#E74C3C' if p < 0.05/len(chi2) else '#95A5A6' 
              for p in chi2['p-value']]
    
    ax1.bar(x, -np.log10(chi2['p-value']), color=colors, width=0.8, alpha=0.8)
    ax1.axhline(-np.log10(0.05), color='orange', ls='--', lw=1.5, label='α = 0.05')
    ax1.axhline(-np.log10(0.05/len(chi2)), color='red', ls='--', lw=1.5, 
               label=f'Bonferroni α = {0.05/len(chi2):.1e}')
    
    ax1.set_ylabel('-log$_{10}$(p-value)', fontsize=12, fontweight='bold')
    ax1.set_title('A   Chi-square Test Results', fontsize=13, fontweight='bold', loc='left')
    ax1.legend(fontsize=10)
    ax1.grid(alpha=0.3, axis='y')
    
    # Panel B: Fisher's Exact heatmap
    ax2 = fig.add_subplot(gs[1, 0])
    
    fisher_matrix = np.array([
        [fisher['Significant_Uzbek_EUR'].sum(), 
         fisher['Significant_Uzbek_EAS'].sum()],
        [fisher['Significant_Uzbek_EUR'].sum(), 
         fisher['Significant_EUR_EAS'].sum()]
    ])
    
    sns.heatmap([[fisher['Significant_Uzbek_EUR'].sum()], 
                 [fisher['Significant_Uzbek_EAS'].sum()],
                 [fisher['Significant_EUR_EAS'].sum()]],
               annot=True, fmt='d', cmap='RdYlBu_r', ax=ax2,
               yticklabels=['Uzbek-EUR', 'Uzbek-EAS', 'EUR-EAS'],
               xticklabels=['Significant'], cbar_kws={'label': 'Count'})
    
    ax2.set_title('B   Fisher\'s Exact', fontsize=13, fontweight='bold', loc='left')
    
    # Panel C: G-test comparison
    ax3 = fig.add_subplot(gs[1, 1])
    
    ax3.scatter(chi2['Chi2'], gtest['G_statistic'], alpha=0.6, s=50)
    
    # Diagonal line
    max_val = max(chi2['Chi2'].max(), gtest['G_statistic'].max())
    ax3.plot([0, max_val], [0, max_val], 'r--', lw=2, label='x=y')
    
    ax3.set_xlabel('χ² statistic', fontsize=12)
    ax3.set_ylabel('G statistic', fontsize=12)
    ax3.set_title('C   G-test vs χ²', fontsize=13, fontweight='bold', loc='left')
    ax3.legend()
    ax3.grid(alpha=0.3)
    
    # Panel D: Cochran-Armitage trend
    ax4 = fig.add_subplot(gs[1, 2])
    
    trend_counts = ca['Trend'].value_counts()
    colors_trend = ['#2ECC71', '#E74C3C', '#95A5A6']
    
    ax4.bar(range(len(trend_counts)), trend_counts.values, 
           color=colors_trend[:len(trend_counts)], alpha=0.8, edgecolor='black', lw=1.5)
    ax4.set_xticks(range(len(trend_counts)))
    ax4.set_xticklabels(trend_counts.index, rotation=45, ha='right')
    ax4.set_ylabel('Number of Loci', fontsize=12)
    ax4.set_title('D   Cochran-Armitage Trends', fontsize=13, fontweight='bold', loc='left')
    ax4.grid(alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('outputs/SuppFigure_Statistical_Summary.png', dpi=DPI, bbox_inches='tight')
    plt.close()
    
    print("  ✓ SuppFigure_Statistical_Summary.png")

def plot_fst_heatmap():
    """
    Figure 2: FST heatmap and distance matrix.
    """
    print("[5/5] Creating FST heatmap...")
    
    fst_df = pd.read_csv("outputs/fst_matrix.csv")
    fst_matrix = fst_df[['Uzbek', 'EUR', 'EAS']].values
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # FST heatmap
    sns.heatmap(fst_matrix, annot=True, fmt='.4f', cmap='YlOrRd',
               xticklabels=['Uzbek', 'EUR', 'EAS'],
               yticklabels=['Uzbek', 'EUR', 'EAS'],
               cbar_kws={'label': 'F$_{ST}$'}, ax=ax1,
               square=True, linewidths=2, linecolor='black')
    
    ax1.set_title('A   Pairwise F$_{ST}$ Matrix', fontsize=14, fontweight='bold', loc='left')
    
    # Dendrogram (simple UPGMA)
    from scipy.cluster.hierarchy import dendrogram, linkage
    from scipy.spatial.distance import squareform
    
    condensed_dist = squareform(fst_matrix)
    linkage_matrix = linkage(condensed_dist, method='average')
    
    dendrogram(linkage_matrix, labels=['Uzbek', 'EUR', 'EAS'], 
              ax=ax2, color_threshold=0, above_threshold_color='#3498DB')
    
    ax2.set_ylabel('F$_{ST}$ Distance', fontsize=12, fontweight='bold')
    ax2.set_title('B   UPGMA Dendrogram', fontsize=14, fontweight='bold', loc='left')
    ax2.grid(alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('outputs/Figure2_FST_Heatmap.png', dpi=DPI, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Figure2_FST_Heatmap.png")

def main():
    """Main visualization pipeline."""
    
    print("="*80)
    print("PUBLICATION-QUALITY VISUALIZATIONS")
    print("="*80)
    print()
    
    # Check inputs
    check_inputs()
    
    # Generate figures
    plot_fst_manhattan()
    plot_admixture_barplot()
    plot_pca_biplot()
    plot_statistical_summary()
    plot_fst_heatmap()
    
    print()
    print("="*80)
    print("ALL VISUALIZATIONS COMPLETE")
    print("="*80)
    print()
    print("Generated figures:")
    print("  Figure2_FST_Heatmap.png")
    print("  Figure3_PCA_Biplot.png")
    print("  Figure4_FST_Manhattan.png")
    print("  Figure6_Admixture_Barplot.png")
    print("  SuppFigure_Statistical_Summary.png")
    print()
    print(f"All figures saved at {DPI} dpi in outputs/")

if __name__ == "__main__":
    main()
