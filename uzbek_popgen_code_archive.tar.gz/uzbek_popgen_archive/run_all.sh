#!/bin/bash
# Run all analysis scripts in order

echo "===================================================================="
echo "UZBEK POPULATION GENETICS - COMPLETE ANALYSIS PIPELINE"
echo "===================================================================="
echo ""

echo "[1/5] Running FST analysis..."
python scripts/01_fst_analysis.py
if [ $? -ne 0 ]; then
    echo "ERROR: FST analysis failed"
    exit 1
fi
echo ""

echo "[2/5] Running PCA..."
python scripts/02_pca_analysis.py
if [ $? -ne 0 ]; then
    echo "ERROR: PCA failed"
    exit 1
fi
echo ""

echo "[3/5] Running admixture analysis..."
python scripts/03_admixture_analysis.py
if [ $? -ne 0 ]; then
    echo "ERROR: Admixture analysis failed"
    exit 1
fi
echo ""

echo "[4/5] Running statistical tests..."
python scripts/04_statistical_tests.py
if [ $? -ne 0 ]; then
    echo "ERROR: Statistical tests failed"
    exit 1
fi
echo ""

echo "[5/5] Generating visualizations..."
python scripts/05_visualizations.py
if [ $? -ne 0 ]; then
    echo "ERROR: Visualization failed"
    exit 1
fi
echo ""

echo "===================================================================="
echo "ALL ANALYSES COMPLETE!"
echo "===================================================================="
echo ""
echo "Results saved in outputs/ directory"
echo "Figures saved at 300 dpi"
echo ""
