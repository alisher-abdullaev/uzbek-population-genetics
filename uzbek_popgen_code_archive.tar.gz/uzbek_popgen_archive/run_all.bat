@echo off
REM Run all analysis scripts in order

echo ====================================================================
echo UZBEK POPULATION GENETICS - COMPLETE ANALYSIS PIPELINE
echo ====================================================================
echo.

echo [1/5] Running FST analysis...
python scripts\01_fst_analysis.py
if errorlevel 1 (
    echo ERROR: FST analysis failed
    exit /b 1
)
echo.

echo [2/5] Running PCA...
python scripts\02_pca_analysis.py
if errorlevel 1 (
    echo ERROR: PCA failed
    exit /b 1
)
echo.

echo [3/5] Running admixture analysis...
python scripts\03_admixture_analysis.py
if errorlevel 1 (
    echo ERROR: Admixture analysis failed
    exit /b 1
)
echo.

echo [4/5] Running statistical tests...
python scripts\04_statistical_tests.py
if errorlevel 1 (
    echo ERROR: Statistical tests failed
    exit /b 1
)
echo.

echo [5/5] Generating visualizations...
python scripts\05_visualizations.py
if errorlevel 1 (
    echo ERROR: Visualization failed
    exit /b 1
)
echo.

echo ====================================================================
echo ALL ANALYSES COMPLETE!
echo ====================================================================
echo.
echo Results saved in outputs\ directory
echo Figures saved at 300 dpi
echo.
pause
